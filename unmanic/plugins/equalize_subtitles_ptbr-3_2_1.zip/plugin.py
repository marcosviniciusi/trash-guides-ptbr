#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Equalize Subtitles PT-BR

- Keeps only PT-BR subtitles embedded in the MKV
- Extracts EN and audio-language subtitles as external .srt files
- Removes all other subtitle languages from the container
- Converts ASS/SSA -> SRT
- Tags files as processed to avoid reprocessing
"""

import logging
import os
import re
import subprocess

from unmanic.libs.unplugins.settings import PluginSettings

from equalize_subtitles_ptbr.lib.ffmpeg import StreamMapper, Probe, Parser

logger = logging.getLogger("Unmanic.Plugin.equalize_subtitles_ptbr")


class Settings(PluginSettings):
    settings = {}


# --- Language helpers ---

PT_CODES = frozenset([
    'por', 'pt', 'pt-br', 'pt-pt', 'pob', 'pb', 'ptbr',
    'portuguese', 'portugues', 'brazilian', 'brasil', 'brazil',
])

EN_CODES = frozenset([
    'eng', 'en', 'en-us', 'enus', 'english',
])

TEXT_SUBTITLE_CODECS = frozenset([
    'ass', 'ssa', 'subrip', 'srt', 'webvtt', 'mov_text',
])

ALL_SUBTITLE_CODECS = TEXT_SUBTITLE_CODECS | frozenset([
    'hdmv_pgs_subtitle', 'pgssub', 'pgs',
])


def is_portuguese(lang):
    return lang.lower() in PT_CODES if lang else False


def is_english(lang):
    return lang.lower() in EN_CODES if lang else False


def is_audio_language(lang, audio_languages):
    if not lang or not audio_languages:
        return False
    if is_portuguese(lang) or is_english(lang):
        return False
    lang_lower = lang.lower()
    for audio_lang in audio_languages:
        if not audio_lang:
            continue
        if lang_lower == audio_lang.lower() or lang_lower[:2] == audio_lang.lower()[:2]:
            return True
    return False


def get_audio_languages(probe):
    languages = []
    file_probe = probe.get_probe()
    for stream in file_probe.get('streams', []):
        if stream.get('codec_type') == 'audio':
            lang = stream.get('tags', {}).get('language', '')
            if lang and lang not in languages:
                languages.append(lang)
    return languages


def classify_subtitle(codec, lang, audio_languages):
    """
    Returns:
      'embed'   - Keep embedded (PT-BR)
      'extract' - Extract as .srt then remove from MKV (EN + audio lang)
      'remove'  - Remove entirely
      None      - Not a subtitle codec we handle
    """
    if codec not in ALL_SUBTITLE_CODECS:
        return None
    if is_portuguese(lang):
        return 'embed'
    if not lang:
        return 'embed'
    if is_english(lang):
        return 'extract' if codec in TEXT_SUBTITLE_CODECS else 'remove'
    if is_audio_language(lang, audio_languages):
        return 'extract' if codec in TEXT_SUBTITLE_CODECS else 'remove'
    return 'remove'


def build_subtitle_tag(stream_info):
    subtitle_tag = ''
    stream_tags = stream_info.get('tags', {})
    if stream_tags.get('language'):
        subtitle_tag = '{}.{}'.format(subtitle_tag, stream_tags.get('language'))
    if stream_tags.get('title'):
        subtitle_tag = '{}.{}'.format(subtitle_tag, stream_tags.get('title'))
    if not subtitle_tag:
        subtitle_tag = '{}.{}'.format(subtitle_tag, stream_info.get('index'))
    subtitle_tag = re.sub(r'\s', '-', subtitle_tag)
    return subtitle_tag


# --- StreamMapper subclass (same pattern as official plugins) ---

class PluginStreamMapper(StreamMapper):
    def __init__(self):
        super(PluginStreamMapper, self).__init__(logger, ['subtitle'])
        self.audio_languages = []

    def set_audio_languages(self, languages):
        self.audio_languages = languages

    def test_stream_needs_processing(self, stream_info: dict):
        codec = stream_info.get('codec_name', '').lower()
        lang = stream_info.get('tags', {}).get('language', '')

        action = classify_subtitle(codec, lang, self.audio_languages)
        if action is None:
            return False

        # Needs removal or extraction? Process it.
        if action in ('remove', 'extract'):
            return True

        # Embedded but ASS/SSA? Needs conversion.
        if action == 'embed' and codec in ('ass', 'ssa'):
            return True

        # Embedded but no language? Needs tagging.
        if action == 'embed' and not lang:
            return True

        return False

    def custom_stream_mapping(self, stream_info: dict, stream_id: int):
        codec = stream_info.get('codec_name', '').lower()
        lang = stream_info.get('tags', {}).get('language', '')

        action = classify_subtitle(codec, lang, self.audio_languages)

        # Remove or extract -> don't map (extraction done separately via subprocess)
        if action in ('remove', 'extract'):
            logger.info("[WORKER] %s subtitle: lang=%s (input s:%d)",
                        'Extracting' if action == 'extract' else 'Removing', lang, stream_id)
            return {
                'stream_mapping': [],
                'stream_encoding': [],
            }

        # Embed: ASS/SSA -> convert to SRT
        if action == 'embed' and codec in ('ass', 'ssa'):
            encoding = ['-c:s:{}'.format(stream_id), 'subrip']
            if not lang:
                encoding += [
                    '-metadata:s:s:{}'.format(stream_id), 'language=por',
                    '-metadata:s:s:{}'.format(stream_id), 'title=Brazilian Portuguese',
                ]
            logger.info("[WORKER] Converting %s -> SRT (s:%d)", codec.upper(), stream_id)
            return {
                'stream_mapping': ['-map', '0:s:{}'.format(stream_id)],
                'stream_encoding': encoding,
            }

        # Embed: no language -> tag as PT-BR
        if action == 'embed' and not lang:
            logger.info("[WORKER] Tagging stream s:%d as PT-BR", stream_id)
            return {
                'stream_mapping': ['-map', '0:s:{}'.format(stream_id)],
                'stream_encoding': [
                    '-c:s:{}'.format(stream_id), 'copy',
                    '-metadata:s:s:{}'.format(stream_id), 'language=por',
                    '-metadata:s:s:{}'.format(stream_id), 'title=Brazilian Portuguese',
                ],
            }

        # Fallback: copy
        return {
            'stream_mapping': ['-map', '0:s:{}'.format(stream_id)],
            'stream_encoding': ['-c:s:{}'.format(stream_id), 'copy'],
        }


# --- Library file test ---

def on_library_management_file_test(data):
    abspath = data.get('path')
    logger.info("[TEST] Checking: %s", abspath)

    probe = Probe(logger, allowed_mimetypes=['video'])
    if not probe.file(abspath):
        logger.info("[TEST] Not a video file, skipping: %s", abspath)
        return data

    file_probe = probe.get_probe()
    format_tags = file_probe.get('format', {}).get('tags', {})
    for tag_key, tag_value in format_tags.items():
        if tag_key.lower() in ('unmanic-equalize-subtitles-v2', 'unmanic_equalize_subtitles_v2'):
            if str(tag_value).lower() in ('true', '1', 'yes'):
                logger.info("[TEST] Already processed, skipping: %s", abspath)
                return data

    audio_languages = get_audio_languages(probe)
    logger.info("[TEST] Audio languages: %s", audio_languages)

    mapper = PluginStreamMapper()
    mapper.set_audio_languages(audio_languages)
    mapper.set_probe(probe)

    if mapper.streams_need_processing():
        data['add_file_to_pending_tasks'] = True
        logger.info("[TEST] Added to pending tasks: %s", abspath)
    else:
        logger.info("[TEST] No processing needed: %s", abspath)

    return data


# --- Worker process ---

def on_worker_process(data):
    data['exec_command'] = []
    data['repeat'] = False

    abspath = data.get('file_in')
    original_file_path = data.get('original_file_path')

    probe = Probe(logger, allowed_mimetypes=['video'])
    if not probe.file(abspath):
        return data

    audio_languages = get_audio_languages(probe)

    mapper = PluginStreamMapper()
    mapper.set_audio_languages(audio_languages)
    mapper.set_probe(probe)

    if not mapper.streams_need_processing():
        logger.info("[WORKER] No work needed: %s", abspath)
        return data

    # --- Phase 1: Extract EN and audio-language subtitles as .srt files ---
    file_probe = probe.get_probe()
    streams = file_probe.get('streams', [])
    split_original = os.path.splitext(original_file_path)
    original_dir = os.path.dirname(original_file_path)

    s_in = 0
    for stream in streams:
        if stream.get('codec_type') != 'subtitle':
            continue
        codec = stream.get('codec_name', '').lower()
        lang = stream.get('tags', {}).get('language', '')
        action = classify_subtitle(codec, lang, audio_languages)

        if action == 'extract':
            subtitle_tag = build_subtitle_tag(stream)
            srt_path = os.path.join(original_dir, '{}{}.srt'.format(split_original[0], subtitle_tag))

            extract_cmd = [
                'ffmpeg', '-hide_banner', '-loglevel', 'warning',
                '-i', abspath,
                '-map', '0:s:{}'.format(s_in),
                '-c:s', 'subrip',
                '-y', srt_path,
            ]
            logger.info("[WORKER] Extracting subtitle s:%d (%s) -> %s", s_in, lang, srt_path)
            try:
                result = subprocess.run(extract_cmd, capture_output=True, text=True, timeout=120)
                if result.returncode == 0:
                    logger.info("[WORKER] Extraction OK: %s", srt_path)
                else:
                    logger.error("[WORKER] Extraction failed for s:%d: %s", s_in, result.stderr)
            except Exception as e:
                logger.error("[WORKER] Extraction exception for s:%d: %s", s_in, str(e))

        s_in += 1

    # --- Phase 2: Remux using StreamMapper (same pattern as official plugins) ---
    mapper.set_input_file(abspath)
    mapper.set_output_file(data.get('file_out'))

    ffmpeg_args = mapper.get_ffmpeg_args()

    # Inject metadata tag before the output file (last 2 args are -y output)
    ffmpeg_args = ffmpeg_args[:-2] + ['-metadata', 'unmanic-equalize-subtitles-v2=true'] + ffmpeg_args[-2:]

    data['exec_command'] = ['ffmpeg']
    data['exec_command'] += ffmpeg_args

    logger.info("[WORKER] FFmpeg command: %s", ' '.join(data['exec_command']))

    parser = Parser(logger)
    parser.set_probe(probe)
    data['command_progress_parser'] = parser.parse_progress

    return data
