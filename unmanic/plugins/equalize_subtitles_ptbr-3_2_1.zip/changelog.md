**3.2.1** - Rewritten to use StreamMapper (same pattern as official plugins)
- CHANGED: Worker now uses StreamMapper.get_ffmpeg_args() instead of manual arg building
- CHANGED: Follows exact same flow as remove_image_subtitles: streams_need_processing → set_input_file → set_output_file → get_ffmpeg_args
- FIX: Unmanic should now properly handle the output file movement
- Phase 1 (subprocess): extracts EN/audio-lang as .srt before remux
- Phase 2 (StreamMapper): remux keeping only PT-BR embedded

**3.2.0** - New subtitle logic + extraction
- CHANGED: PT-BR subtitles are the ONLY ones kept embedded in the MKV
- NEW: EN and audio-language subtitles extracted as external .srt files
- NEW: is_audio_language no longer matches PT/EN

**3.1.0** - Major rewrite fixing all bugs
- FIX: Removed dependency on StreamMapper for worker process
- FIX: SSA subtitles now properly converted to SRT
- FIX: Output subtitle indices tracked separately from input

**3.0.4** - Initial release
