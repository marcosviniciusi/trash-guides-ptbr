#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
    unmanic-plugins.plugin.py

    Written by:               Josh.5 <jsunnex@gmail.com>
    Modified by:              Marcos Gabriel
    Date:                     23 Feb 2025

    Copyright:
        Copyright (C) 2021 Josh Sunnex
        Copyright (C) 2025 Marcos Gabriel

        This program is free software: you can redistribute it and/or modify it under the terms of the GNU General
        Public License as published by the Free Software Foundation, version 3.

        This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
        implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
        for more details.

        You should have received a copy of the GNU General Public License along with this program.
        If not, see <https://www.gnu.org/licenses/>.

"""
import logging
import os

from unmanic.libs.unplugins.settings import PluginSettings

from dts_flac_to_dd.lib.ffmpeg import StreamMapper, Probe, Parser

# Configure plugin logger
logger = logging.getLogger("Unmanic.Plugin.dts_flac_to_dd")


class Settings(PluginSettings):
    settings = {
        'create_aac_stereo':     True,
        'aac_stereo_bitrate':    '128k',
        'create_ac3_stereo':     True,
        'ac3_stereo_bitrate':    '192k',
        'create_ac3_surround':   True,
        'ac3_surround_bitrate':  '640k',
        'create_eac3_surround':  True,
        'eac3_surround_bitrate': '1536k',
        'remove_non_dolby':      True,
    }
    
    form_settings = {
        "create_aac_stereo": {
            "label": "Create AAC stereo downmix from all surround audio (> 2.0 channels)",
            "input_type": "checkbox",
        },
        "aac_stereo_bitrate": {
            "label":      "AAC stereo bitrate",
            "sub_setting": True,
            "input_type": "select",
            "select_options": [
                {
                    'value': "96k",
                    'label': "96 kbps (low, mobile data saving)",
                },
                {
                    'value': "128k",
                    'label': "128 kbps (recommended, streaming quality)",
                },
                {
                    'value': "160k",
                    'label': "160 kbps (high quality)",
                },
                {
                    'value': "192k",
                    'label': "192 kbps (excellent quality)",
                },
                {
                    'value': "256k",
                    'label': "256 kbps (near-transparent)",
                },
                {
                    'value': "320k",
                    'label': "320 kbps (maximum)",
                },
            ],
        },
        "create_ac3_stereo": {
            "label": "Create AC3 stereo downmix from all surround audio (> 2.0 channels)",
            "input_type": "checkbox",
        },
        "ac3_stereo_bitrate": {
            "label":      "AC3 stereo bitrate",
            "sub_setting": True,
            "input_type": "select",
            "select_options": [
                {
                    'value': "128k",
                    'label': "128 kbps",
                },
                {
                    'value': "160k",
                    'label': "160 kbps",
                },
                {
                    'value': "192k",
                    'label': "192 kbps (recommended)",
                },
                {
                    'value': "224k",
                    'label': "224 kbps",
                },
                {
                    'value': "256k",
                    'label': "256 kbps (high quality)",
                },
                {
                    'value': "320k",
                    'label': "320 kbps (maximum)",
                },
            ],
        },
        "create_ac3_surround": {
            "label": "Create AC3 5.1 surround from non-Dolby codecs (DTS, FLAC, Opus, etc)",
            "input_type": "checkbox",
        },
        "ac3_surround_bitrate": {
            "label":      "AC3 surround bitrate",
            "sub_setting": True,
            "input_type": "select",
            "select_options": [
                {
                    'value': "384k",
                    'label': "384 kbps (5.1 balanced)",
                },
                {
                    'value': "448k",
                    'label': "448 kbps (5.1 good)",
                },
                {
                    'value': "640k",
                    'label': "640 kbps (5.1 maximum, recommended)",
                },
            ],
        },
        "create_eac3_surround": {
            "label": "Create EAC3 5.1 surround from non-Dolby codecs (DTS, FLAC, Opus, etc)",
            "input_type": "checkbox",
        },
        "eac3_surround_bitrate": {
            "label":      "EAC3 surround bitrate",
            "sub_setting": True,
            "input_type": "select",
            "select_options": [
                {
                    'value': "768k",
                    'label': "768 kbps (5.1 balanced)",
                },
                {
                    'value': "1024k",
                    'label': "1024 kbps (5.1 good)",
                },
                {
                    'value': "1536k",
                    'label': "1536 kbps (5.1 maximum, recommended)",
                },
            ],
        },
        "remove_non_dolby": {
            "label": "Remove non-Dolby originals after conversion (keeps TrueHD, AC3, EAC3, AAC)",
            "input_type": "checkbox",
        },
    }


class PluginStreamMapper(StreamMapper):
    def __init__(self):
        super(PluginStreamMapper, self).__init__(logger, ['audio'])
        self.settings = None
        self.stream_encoding_map = {}

    def set_settings(self, settings):
        self.settings = settings

    def should_process_stream(self, probe_stream):
        """
        Check if this stream should be processed
        Processes ALL audio > 2.0 for stereo downmix
        Processes audio == 2.0 if non-Dolby/non-AAC (converts to AAC/AC3 stereo)
        Processes non-Dolby/non-AAC for surround conversion
        """
        codec_name = probe_stream.get('codec_name', '').lower()
        channels = probe_stream.get('channels', 0)
        
        is_dolby = codec_name in ['ac3', 'eac3', 'truehd']
        is_aac = codec_name == 'aac'
        
        # Process if any stereo downmix is enabled and stream has > 2 channels
        if channels > 2:
            if self.settings.get_setting('create_aac_stereo'):
                return True
            if self.settings.get_setting('create_ac3_stereo'):
                return True
        
        # Process if stereo (2.0) and non-Dolby/non-AAC (DTS 2.0, FLAC 2.0, Opus 2.0, etc)
        if channels == 2 and not is_dolby and not is_aac:
            if self.settings.get_setting('create_aac_stereo'):
                return True
            if self.settings.get_setting('create_ac3_stereo'):
                return True
        
        # Process if surround is enabled and codec is non-Dolby/non-AAC
        if not is_dolby and not is_aac and channels > 2:
            if self.settings.get_setting('create_ac3_surround'):
                return True
            if self.settings.get_setting('create_eac3_surround'):
                return True
        
        return False
    
    def is_dolby_codec(self, codec_name):
        """Check if codec is Dolby family"""
        return codec_name.lower() in ['ac3', 'eac3', 'truehd']
    
    def is_aac_codec(self, codec_name):
        """Check if codec is AAC"""
        return codec_name.lower() == 'aac'
    
    def get_detailed_title(self, codec, channels, bitrate, sample_rate=48000):
        """
        Generate detailed audio track title similar to professional releases
        
        Format: "Codec Layout / Description / Layout / Sample_Rate / Bitrate"
        Example: "AC3 5.1 / Dolby Digital Audio / 5.1 / 48 kHz / 640 kbps"
        
        Args:
            codec: Output codec ('aac', 'ac3', 'eac3')
            channels: Number of channels
            bitrate: Bitrate string (e.g., '640k')
            sample_rate: Sample rate in Hz (default: 48000)
        
        Returns:
            Detailed title string
        """
        # Determine channel layout name
        if channels == 1:
            layout = "Mono"
            layout_short = "1.0"
        elif channels == 2:
            layout = "Stereo"
            layout_short = "2.0"
        elif channels == 6:
            layout = "5.1"
            layout_short = "5.1"
        elif channels == 8:
            layout = "7.1"
            layout_short = "7.1"
        else:
            layout = f"{channels}.0"
            layout_short = f"{channels}.0"
        
        # Determine codec description
        if codec == 'aac':
            codec_name = "AAC"
            description = "Advanced Audio Codec"
        elif codec == 'ac3':
            codec_name = "AC3"
            description = "Dolby Digital Audio"
        elif codec == 'eac3':
            codec_name = "EAC3"
            description = "Dolby Digital Plus"
        else:
            codec_name = codec.upper()
            description = "Audio"
        
        # Convert sample rate to kHz
        sample_rate_khz = sample_rate // 1000
        
        # Convert bitrate to numeric (remove 'k')
        bitrate_num = bitrate.replace('k', '')
        
        # Build complete title
        # Format: "Codec Layout / Description / Layout / Sample_Rate / Bitrate"
        title = f"{codec_name} {layout} / {description} / {layout_short} / {sample_rate_khz} kHz / {bitrate_num} kbps"
        
        return title
    
    def get_smart_bitrate(self, source_bitrate, config_bitrate, codec, channels, source_codec=''):
        """
        Get smart bitrate based on source and config
        Prevents unnecessary upscaling while maintaining minimum quality
        
        Strategy:
        - Stereo: min(source, config) - no floor
        - Surround + modern codecs (Opus/Vorbis/AAC): min(source, config) with floor
        - Surround + traditional codecs (DTS/FLAC): min(source, config) - no floor
        
        Args:
            source_bitrate: Original stream bitrate (int, in bps)
            config_bitrate: Configured target bitrate (str, e.g. '640k')
            codec: Target codec ('aac', 'ac3', 'eac3')
            channels: Number of channels
            source_codec: Original codec name (e.g., 'opus', 'dts', 'aac')
        
        Returns:
            Smart bitrate string (e.g., '384k')
        """
        # Convert config bitrate string to int (e.g., '640k' -> 640000)
        config_bps = int(config_bitrate.replace('k', '')) * 1000
        
        # For stereo: use minimum without floor
        # AAC/AC3 work well even at 96k for stereo
        if channels <= 2:
            target_bps = min(source_bitrate, config_bps)
            return f"{target_bps // 1000}k"
        
        # For surround: check if source is modern/efficient codec
        source_codec_lower = source_codec.lower()
        is_modern_codec = source_codec_lower in ['opus', 'vorbis', 'aac']
        
        # Calculate minimum target
        target_bps = min(source_bitrate, config_bps)
        
        # Apply floor only for modern/efficient source codecs
        # These codecs are much more efficient than AC3/EAC3, so need upscaling
        if is_modern_codec:
            if codec == 'aac':
                floor_bps = 192000  # 192k minimum for AAC 5.1 from efficient sources
            elif codec == 'ac3':
                floor_bps = 256000  # 256k minimum for AC3 5.1 from efficient sources
            elif codec == 'eac3':
                floor_bps = 384000  # 384k minimum for EAC3 5.1 from efficient sources
            else:
                floor_bps = 256000  # Default floor
            
            final_bps = max(target_bps, floor_bps)
        else:
            # DTS/FLAC: no floor, they already have adequate bitrate
            final_bps = target_bps
        
        return f"{final_bps // 1000}k"

    def test_stream_needs_processing(self, stream_info: dict):
        """
        Test if this stream needs processing
        """
        if self.should_process_stream(stream_info):
            return True
        return False

    def custom_stream_mapping(self, stream_info: dict, stream_id: int):
        """
        Create custom stream mapping for audio conversion v1.2.0
        
        Order of operations (CRITICAL - prevents infinite loop):
        1. Create AAC stereo (if > 2.0 OR if 2.0 non-Dolby/non-AAC)
        2. Create AC3 stereo (if > 2.0 OR if 2.0 non-Dolby/non-AAC)
        3. Create AC3 surround (if non-Dolby/non-AAC AND > 2.0)
        4. Create EAC3 surround (if non-Dolby/non-AAC AND > 2.0)
        5. Keep or remove original based on codec type
        
        Codec categories:
        - Dolby: TrueHD, AC3, EAC3 (creates stereo only, keeps original)
        - AAC: All AAC (creates stereo only, keeps original)
        - Non-Dolby 2.0: DTS, FLAC, Opus stereo (converts to AAC/AC3 stereo, removes if enabled)
        - Non-Dolby >2.0: DTS, FLAC, Opus surround (creates all, removes if enabled)
        """
        codec_name = stream_info.get('codec_name', '').lower()
        channels = stream_info.get('channels', 2)
        original_lang = stream_info.get('tags', {}).get('language', '')
        source_bitrate = stream_info.get('bit_rate', 0)
        
        # Convert source bitrate to int (it comes as string or None)
        try:
            source_bitrate = int(source_bitrate) if source_bitrate else 0
        except (ValueError, TypeError):
            source_bitrate = 0
        
        # If bitrate not available or is 0, use a safe default based on codec
        if source_bitrate == 0:
            if codec_name in ['dts', 'flac']:
                source_bitrate = 1536000  # Assume high quality
            elif codec_name in ['opus', 'vorbis']:
                source_bitrate = 256000   # Assume medium quality
            elif codec_name == 'aac':
                source_bitrate = 256000
            else:
                source_bitrate = 384000   # Safe default
        
        logger.info(f"Processing {codec_name.upper()} stream (ID: {stream_id}, Channels: {channels}, Bitrate: {source_bitrate // 1000}k)")
        
        stream_mapping = []
        stream_encoding = []
        output_track_count = 0
        
        is_dolby = self.is_dolby_codec(codec_name)
        is_aac = self.is_aac_codec(codec_name)
        is_non_dolby_non_aac = not is_dolby and not is_aac
        
        # STEP 1: Create AAC stereo
        # - From surround (> 2.0) = downmix
        # - From non-Dolby/non-AAC stereo (2.0) = transcode
        should_create_aac_stereo = (
            self.settings.get_setting('create_aac_stereo') and 
            (channels > 2 or (channels == 2 and is_non_dolby_non_aac))
        )
        
        if should_create_aac_stereo:
            config_aac_bitrate = self.settings.get_setting('aac_stereo_bitrate')
            # Use smart bitrate to prevent unnecessary upscaling
            aac_bitrate = self.get_smart_bitrate(source_bitrate, config_aac_bitrate, 'aac', channels, codec_name)
            
            stream_mapping += ['-map', f'0:a:{stream_id}']
            output_stream_id = stream_id + output_track_count
            
            # Generate detailed title
            title = self.get_detailed_title('aac', 2, aac_bitrate)  # Always stereo (2 channels)
            
            stream_encoding += [
                f'-c:a:{output_stream_id}', 'aac',
                f'-b:a:{output_stream_id}', aac_bitrate,
                f'-ac:a:{output_stream_id}', '2',  # Force stereo
                f'-metadata:s:a:{output_stream_id}', f'title={title}',
            ]
            
            if original_lang:
                stream_encoding += [f'-metadata:s:a:{output_stream_id}', f'language={original_lang}']
            
            if channels > 2:
                logger.info(f"Creating AAC stereo downmix: {aac_bitrate}")
            else:
                logger.info(f"Creating AAC stereo transcode: {aac_bitrate}")
            output_track_count += 1
        
        # STEP 2: Create AC3 stereo
        # - From surround (> 2.0) = downmix
        # - From non-Dolby/non-AAC stereo (2.0) = transcode
        should_create_ac3_stereo = (
            self.settings.get_setting('create_ac3_stereo') and 
            (channels > 2 or (channels == 2 and is_non_dolby_non_aac))
        )
        
        if should_create_ac3_stereo:
            config_ac3_stereo_bitrate = self.settings.get_setting('ac3_stereo_bitrate')
            # Use smart bitrate to prevent unnecessary upscaling
            ac3_stereo_bitrate = self.get_smart_bitrate(source_bitrate, config_ac3_stereo_bitrate, 'ac3', channels, codec_name)
            
            stream_mapping += ['-map', f'0:a:{stream_id}']
            output_stream_id = stream_id + output_track_count
            
            # Generate detailed title
            title = self.get_detailed_title('ac3', 2, ac3_stereo_bitrate)  # Always stereo (2 channels)
            
            stream_encoding += [
                f'-c:a:{output_stream_id}', 'ac3',
                f'-b:a:{output_stream_id}', ac3_stereo_bitrate,
                f'-ac:a:{output_stream_id}', '2',  # Force stereo
                f'-metadata:s:a:{output_stream_id}', f'title={title}',
            ]
            
            if original_lang:
                stream_encoding += [f'-metadata:s:a:{output_stream_id}', f'language={original_lang}']
            
            if channels > 2:
                logger.info(f"Creating AC3 stereo downmix: {ac3_stereo_bitrate}")
            else:
                logger.info(f"Creating AC3 stereo transcode: {ac3_stereo_bitrate}")
            output_track_count += 1
        
        # STEP 3: Create AC3 surround (non-Dolby/non-AAC AND > 2.0 only)
        if is_non_dolby_non_aac and channels > 2 and self.settings.get_setting('create_ac3_surround'):
            config_ac3_surround_bitrate = self.settings.get_setting('ac3_surround_bitrate')
            # Use smart bitrate with floor for surround quality
            ac3_surround_bitrate = self.get_smart_bitrate(source_bitrate, config_ac3_surround_bitrate, 'ac3', channels, codec_name)
            
            stream_mapping += ['-map', f'0:a:{stream_id}']
            output_stream_id = stream_id + output_track_count
            
            # Generate detailed title
            title = self.get_detailed_title('ac3', channels, ac3_surround_bitrate)
            
            stream_encoding += [
                f'-c:a:{output_stream_id}', 'ac3',
                f'-b:a:{output_stream_id}', ac3_surround_bitrate,
                f'-metadata:s:a:{output_stream_id}', f'title={title}',
            ]
            
            if original_lang:
                stream_encoding += [f'-metadata:s:a:{output_stream_id}', f'language={original_lang}']
            
            logger.info(f"Creating AC3 surround: {ac3_surround_bitrate}")
            output_track_count += 1
        
        # STEP 4: Create EAC3 surround (non-Dolby/non-AAC AND > 2.0 only)
        if is_non_dolby_non_aac and channels > 2 and self.settings.get_setting('create_eac3_surround'):
            config_eac3_surround_bitrate = self.settings.get_setting('eac3_surround_bitrate')
            # Use smart bitrate with floor for surround quality
            eac3_surround_bitrate = self.get_smart_bitrate(source_bitrate, config_eac3_surround_bitrate, 'eac3', channels, codec_name)
            
            stream_mapping += ['-map', f'0:a:{stream_id}']
            output_stream_id = stream_id + output_track_count
            
            # Generate detailed title
            title = self.get_detailed_title('eac3', channels, eac3_surround_bitrate)
            
            stream_encoding += [
                f'-c:a:{output_stream_id}', 'eac3',
                f'-b:a:{output_stream_id}', eac3_surround_bitrate,
                f'-metadata:s:a:{output_stream_id}', f'title={title}',
            ]
            
            if original_lang:
                stream_encoding += [f'-metadata:s:a:{output_stream_id}', f'language={original_lang}']
            
            logger.info(f"Creating EAC3 surround: {eac3_surround_bitrate}")
            output_track_count += 1
        
        # STEP 5: Handle original stream
        # Remove non-Dolby/non-AAC if setting is enabled
        # Always keep Dolby (TrueHD, AC3, EAC3) and AAC
        if is_non_dolby_non_aac and self.settings.get_setting('remove_non_dolby'):
            logger.info(f"Removing original {codec_name.upper()} track (non-Dolby/non-AAC)")
        else:
            # Keep original (copy)
            stream_mapping += ['-map', f'0:a:{stream_id}']
            output_stream_id = stream_id + output_track_count
            stream_encoding += [f'-c:a:{output_stream_id}', 'copy']
            
            if is_dolby:
                logger.info(f"Keeping original {codec_name.upper()} track (Dolby codec)")
            elif is_aac:
                logger.info(f"Keeping original {codec_name.upper()} track (AAC codec)")
            else:
                logger.info(f"Keeping original {codec_name.upper()} track (remove_non_dolby disabled)")
        
        return {
            'stream_mapping':  stream_mapping,
            'stream_encoding': stream_encoding,
        }
        
        return {
            'stream_mapping':  stream_mapping,
            'stream_encoding': stream_encoding,
        }


def on_library_management_file_test(data):
    """
    Runner function - enables additional actions during the library management file tests.

    The 'data' object argument includes:
        path                            - String containing the full path to the file being tested.
        issues                          - List of currently found issues for not processing the file.
        add_file_to_pending_tasks       - Boolean, is the file currently marked to be added to the queue for processing.

    :param data:
    :return:

    """
    # Get the path to the file
    abspath = data.get('path')

    # Get file probe
    probe = Probe(logger, allowed_mimetypes=['audio', 'video'])
    if not probe.file(abspath):
        # File probe failed, skip the rest of this test
        return data
    
    # Check if file was already processed by this plugin
    # Look for unmanic-audio-processed tag in format tags
    file_probe = probe.get_probe()
    format_tags = file_probe.get('format', {}).get('tags', {})
    
    # Check various possible tag names (case-insensitive)
    already_processed = False
    for tag_key, tag_value in format_tags.items():
        if tag_key.lower() in ['unmanic-audio-processed', 'unmanic_audio_processed']:
            if tag_value.lower() in ['true', '1', 'yes', 'processed']:
                already_processed = True
                logger.info(f"File '{abspath}' already processed (tag: {tag_key}={tag_value}), skipping")
                break
    
    if already_processed:
        # File already processed, skip
        return data

    # Configure settings object (maintain compatibility with v1 plugins)
    if data.get('library_id'):
        settings = Settings(library_id=data.get('library_id'))
    else:
        settings = Settings()

    # Get stream mapper
    mapper = PluginStreamMapper()
    mapper.set_settings(settings)
    mapper.set_probe(probe)

    if mapper.streams_need_processing():
        # Mark this file to be added to the pending tasks
        data['add_file_to_pending_tasks'] = True
        logger.debug("File '{}' should be added to task list. Probe found streams require processing.".format(abspath))
    else:
        logger.debug("File '{}' does not contain streams require processing.".format(abspath))

    return data


def on_worker_process(data):
    """
    Runner function - enables additional configured processing jobs during the worker stages of a task.

    The 'data' object argument includes:
        exec_command            - A command that Unmanic should execute. Can be empty.
        command_progress_parser - A function that Unmanic can use to parse the STDOUT of the command to collect progress stats. Can be empty.
        file_in                 - The source file to be processed by the command.
        file_out                - The destination that the command should output (may be the same as the file_in if necessary).
        original_file_path      - The absolute path to the original file.
        repeat                  - Boolean, should this runner be executed again once completed with the same variables.

    DEPRECIATED 'data' object args passed for legacy Unmanic versions:
        exec_ffmpeg             - Boolean, should Unmanic run FFMPEG with the data returned from this plugin.
        ffmpeg_args             - A list of Unmanic's default FFMPEG args.

    :param data:
    :return:

    """
    # Default to no FFMPEG command required. This prevents the FFMPEG command from running if it is not required
    data['exec_command'] = []
    data['repeat'] = False
    # DEPRECIATED: 'exec_ffmpeg' kept for legacy Unmanic versions
    data['exec_ffmpeg'] = False

    # Get the path to the file
    abspath = data.get('file_in')

    # Get file probe
    probe = Probe(logger, allowed_mimetypes=['audio', 'video'])
    if not probe.file(abspath):
        # File probe failed, skip the rest of this test
        return data

    # Configure settings object (maintain compatibility with v1 plugins)
    if data.get('library_id'):
        settings = Settings(library_id=data.get('library_id'))
    else:
        settings = Settings()

    # Get stream mapper
    mapper = PluginStreamMapper()
    mapper.set_settings(settings)
    mapper.set_probe(probe)

    if mapper.streams_need_processing():
        # Set the input file
        mapper.set_input_file(abspath)

        # Set the output file
        # Do not remux the file. Keep the file out in the same container
        split_file_in = os.path.splitext(abspath)
        split_file_out = os.path.splitext(data.get('file_out'))
        mapper.set_output_file("{}{}".format(split_file_out[0], split_file_in[1]))

        # Get generated ffmpeg args
        ffmpeg_args = mapper.get_ffmpeg_args()
        
        # Add tag to mark file as processed by this plugin
        # This prevents reprocessing files that already have converted audio
        ffmpeg_args += ['-metadata', 'unmanic-audio-processed=true']

        # Apply ffmpeg args to command
        data['exec_command'] = ['ffmpeg']
        data['exec_command'] += ffmpeg_args
        # DEPRECIATED: 'ffmpeg_args' kept for legacy Unmanic versions
        data['ffmpeg_args'] = ffmpeg_args

        # Set the parser
        parser = Parser(logger)
        parser.set_probe(probe)
        data['command_progress_parser'] = parser.parse_progress

    return data
