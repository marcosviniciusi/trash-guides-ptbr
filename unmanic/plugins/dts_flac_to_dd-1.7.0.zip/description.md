
This plugin converts audio tracks for maximum device compatibility:
- **AAC Stereo** from ANY surround audio (Mi Box, mobile, Bluetooth optimized)
- **AC3 Stereo** from ANY surround audio (TV fallback, universal compatibility)
- **AC3/EAC3 Surround** from non-Dolby codecs only (DTS, FLAC, Opus, etc)
- **Preserves** Dolby (TrueHD/Atmos, AC3, EAC3) and AAC originals

---

## Features v1.2.0

### 🎧 Dual Stereo Downmix (NEW)
- **AAC Stereo 2.0** from ANY audio with > 2.0 channels
  - Optimized for Mi Box, Android, iOS, mobile devices
  - Better efficiency than AC3 (30-40% smaller for same quality)
  - Lower CPU usage and battery consumption
  - Configurable: 96k - 320k bitrate

- **AC3 Stereo 2.0** from ANY audio with > 2.0 channels
  - Universal TV/soundbar fallback compatibility
  - Works on devices from 2005+
  - Configurable: 128k - 320k bitrate

### 🔊 Surround Conversion (Non-Dolby Only)
- Converts **DTS, FLAC, Opus, Vorbis** to **AC3** and **EAC3**
- **PRESERVES** Dolby (TrueHD/Atmos, AC3, EAC3) - NO conversion
- **PRESERVES** AAC - already efficient, no need to convert
- Creates dual tracks for maximum compatibility

### 🎯 Smart Codec Detection
The plugin intelligently preserves high-quality codecs:

**Never Converted (Always Kept):**
- TrueHD / TrueHD Atmos (Dolby lossless)
- AC3 / EAC3 (already Dolby Digital)
- AAC (modern, efficient, widely supported)

**Converted to Dolby:**
- DTS / DTS-HD MA / DTS:X
- FLAC
- Opus / Vorbis
- PCM surround

---

## Why this approach?

**Problem:**
- Mi Box struggles with DTS/TrueHD (high CPU usage)
- TVs support AC3/EAC3 but NOT DTS
- AAC is better than AC3 but not all devices support AAC surround
- Converting AAC → AC3 loses quality (double lossy encoding)

**Solution:**
- **AAC Stereo** = Mi Box/mobile optimization (low CPU, better quality)
- **AC3 Stereo** = Universal TV fallback (everything supports it)
- **AC3 5.1** = Surround fallback for older devices
- **EAC3 5.1** = Better surround for modern devices
- **Keep originals** = TrueHD Atmos/AAC preserved for high-end systems

---

## Processing Logic

### Example 1: DTS 5.1
```
Input: DTS 5.1

Output:
├─ AAC Stereo 2.0 (128k)     ← Mi Box optimized
├─ AC3 Stereo 2.0 (192k)     ← TV fallback
├─ AC3 5.1 (640k)            ← Surround fallback
├─ EAC3 5.1 (1536k)          ← Best surround
└─ (DTS removed)
```

### Example 2: TrueHD Atmos 7.1
```
Input: TrueHD Atmos 7.1

Output:
├─ AAC Stereo 2.0 (128k)     ← Mi Box optimized
├─ AC3 Stereo 2.0 (192k)     ← TV fallback
└─ TrueHD Atmos 7.1          ← PRESERVED (Dolby)
```

### Example 3: AAC 5.1
```
Input: AAC 5.1 (256k)

Output:
├─ AAC Stereo 2.0 (128k)     ← Mi Box optimized
├─ AC3 Stereo 2.0 (192k)     ← TV fallback
└─ AAC 5.1 (256k)            ← PRESERVED (better than AC3!)
```

### Example 4: Opus 5.1
```
Input: Opus 5.1

Output:
├─ AAC Stereo 2.0 (128k)     ← Mi Box optimized
├─ AC3 Stereo 2.0 (192k)     ← TV fallback
├─ AC3 5.1 (640k)            ← Surround fallback
├─ EAC3 5.1 (1536k)          ← Best surround
└─ (Opus removed)
```

---

## Configuration Options

### ☑️ Create AAC stereo downmix
- Creates AAC 2.0 from all > 2.0 channels
- Bitrate options: 96k, 128k (default), 160k, 192k, 256k, 320k
- Best for: Mi Box, mobile, Bluetooth headphones

### ☑️ Create AC3 stereo downmix
- Creates AC3 2.0 from all > 2.0 channels
- Bitrate options: 128k, 160k, 192k (default), 224k, 256k, 320k
- Best for: TVs, universal compatibility

### ☑️ Create AC3 5.1 surround
- Creates AC3 5.1 from non-Dolby/non-AAC only
- Bitrate options: 384k, 448k, 640k (default)
- Best for: Universal surround compatibility

### ☑️ Create EAC3 5.1 surround
- Creates EAC3 5.1 from non-Dolby/non-AAC only
- Bitrate options: 768k, 1024k, 1536k (default)
- Best for: Modern TVs/soundbars, better quality

### ☑️ Remove non-Dolby originals
- Removes: DTS, FLAC, Opus, Vorbis, PCM
- Keeps: TrueHD, AC3, EAC3, AAC
- Saves space while preserving high-quality codecs

---

## What gets processed?

### 🎯 Stereo Downmix (ALL codecs > 2.0):
Creates AAC + AC3 stereo from:
- TrueHD / TrueHD Atmos
- DTS / DTS-HD MA / DTS:X
- AAC surround
- AC3 / EAC3 surround
- Opus / Vorbis
- FLAC
- Any audio with > 2 channels

### ✅ Full Conversion (Non-Dolby/Non-AAC only):
- **All DTS variants:**
  - DTS (Core)
  - DTS-HD Master Audio
  - DTS-HD High Resolution Audio
  - DTS:X (metadata is lost, converts to regular DTS)
  - DTS Express

- **All FLAC:**
  - Any channel configuration (stereo, 5.1, 7.1, etc)

### ❌ Ignored:
- TrueHD / TrueHD Atmos
- AC3 (already compatible)
- EAC3 (already compatible)
- AAC, MP3, Opus, etc.

---

## Output Example

**Before:**
```
Movie.mkv
├── Video: HEVC
├── Audio: DTS 5.1
└── Subtitles
```

**After:**
```
Movie.mkv
├── Video: HEVC
├── Audio 1: AC3 5.1 (640k) - for old devices
├── Audio 2: EAC3 5.1 (1536k) - for modern TVs
└── Subtitles
```

---

## Configuration Options

### Create AC3 track
Enable/disable AC3 conversion. AC3 has maximum compatibility but lower quality ceiling (640 kbps max).

**Bitrate recommendations:**
- **2.0 stereo:** 192-256 kbps
- **5.1 surround:** 384-640 kbps (640k recommended)

### Create EAC3 track
Enable/disable EAC3 conversion. EAC3 offers better quality at higher bitrates (up to 1536 kbps).

**Bitrate recommendations:**
- **2.0 stereo:** 256-384 kbps
- **5.1 surround:** 768-1536 kbps (1536k recommended)

### Remove originals
When enabled, DTS/FLAC tracks are removed after conversion to save space.

**Space savings:**
- DTS-HD MA 5.1: ~3-4 GB → AC3+EAC3: ~1-1.5 GB
- Typical savings: 50-70% per audio track

---

## Channel Handling

**5.1 and below:** Channels preserved
```
DTS 5.1 → AC3 5.1 + EAC3 5.1
FLAC 2.0 → AC3 2.0 + EAC3 2.0
```

**7.1 and above:** Automatic downmix to 5.1
```
DTS 7.1 → AC3 5.1 + EAC3 5.1
```

**Why?** FFmpeg's AC3/EAC3 encoders only support up to 5.1 channels. Most home theater setups are 5.1 anyway.

---

## Quality Notes

### DTS-HD MA (lossless) → AC3/EAC3 (lossy)
Yes, you lose quality. But:
- Most people can't hear the difference on typical setups
- Compatibility is usually more important than audiophile quality
- If you need lossless, keep the original DTS-HD MA

### FLAC (lossless) → AC3/EAC3 (lossy)
- FLAC is typically used for music or high-quality audio
- Converting to lossy reduces quality but improves compatibility
- Consider keeping originals if quality is critical

---

## Use Cases

**Perfect for:**
- Media servers (Plex, Jellyfin, Emby) with mixed device compatibility
- Smart TVs that don't support DTS
- Soundbars with limited codec support
- Reducing storage space while maintaining compatibility

**Not recommended for:**
- Audiophile archival collections
- If all your devices already support DTS/FLAC natively
- Professional audio mastering workflows

---

## Technical Details

- Uses FFmpeg native AC3 and EAC3 encoders
- No external dependencies required
- Preserves video, subtitle, and metadata streams
- Container format unchanged (MKV stays MKV, MP4 stays MP4)

---

## Links

- [FFmpeg AC3 Encoder](https://ffmpeg.org/ffmpeg-codecs.html#ac3)
- [FFmpeg EAC3 Encoder](https://ffmpeg.org/ffmpeg-codecs.html#eac3)
- [Dolby Digital Specification](https://professional.dolby.com/tv/dolby-digital/)
