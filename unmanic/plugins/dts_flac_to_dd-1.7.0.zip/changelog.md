
**<span style="color:#56adda">1.7.0</span>**
- MAJOR FEATURE: Prevents reprocessing of already converted files
- Adds `unmanic-audio-processed=true` metadata tag to processed files
- Plugin automatically skips files with this tag during library scans
- Solves duplicate track creation when rescanning already processed libraries
- Safe to keep plugin enabled permanently - will only process new/unconverted files
- Tag is checked case-insensitively and supports multiple formats

**<span style="color:#56adda">1.6.0</span>**
- IMPROVED: Professional-style audio track titles with full technical details
- Format: "Codec Layout / Description / Layout / Sample Rate / Bitrate"
- Example: "AC3 5.1 / Dolby Digital Audio / 5.1 / 48 kHz / 640 kbps"
- Matches commercial Blu-ray and streaming service metadata standards
- Provides complete audio information at a glance

**<span style="color:#56adda">1.5.0</span>**
- REFINED: Intelligent codec-aware bitrate detection (improved from 1.4.0)
- BUGFIX: Fixed "0k" bitrate in metadata titles when source bitrate unavailable
- Modern efficient codecs (Opus/Vorbis/AAC) get quality floor when converting to AC3/EAC3
- Traditional codecs (DTS/FLAC) bypass floor - already have adequate bitrate
- Quality floors optimized: AC3 256k, EAC3 384k, AAC 192k (based on codec efficiency research)
- Prevents poor quality: Opus 96k 5.1 → AC3 256k (not 96k which sounds terrible)
- Allows proper downgrade: DTS 1536k → AC3 640k (config used, no artificial floor)
- Proper fallback bitrates when source bitrate unavailable: DTS/FLAC 1536k, Opus/Vorbis/AAC 256k
- Research-backed: Opus/AAC are 2-3x more efficient than AC3, requiring upscaling for equivalent quality

**<span style="color:#56adda">1.4.0</span>**
- MAJOR FEATURE: Intelligent codec-aware bitrate detection
- Detects source codec type and applies appropriate quality floors
- Modern efficient codecs (Opus/Vorbis/AAC): min(source, config) with quality floor to prevent poor AC3/EAC3 quality
- Traditional codecs (DTS/FLAC): min(source, config) without floor - already have adequate bitrate
- Stereo tracks: min(source, config) with no floor - works well at any bitrate
- Quality floors for modern codecs converting to surround: AC3 256k, EAC3 384k, AAC 192k
- Examples: Opus 96k 5.1 → AC3 256k, DTS 1536k → AC3 640k, Opus 96k 2.0 → AAC 96k
- Prevents file bloat while ensuring quality: efficient codecs get necessary upscaling, DTS gets downscaling
- Based on research data confirming Opus/AAC are 2-3x more efficient than AC3

**<span style="color:#56adda">1.3.0</span>**
- BUGFIX: DTS/FLAC/Opus 2.0 stereo now uses correct stereo bitrates (128k/192k) instead of surround bitrates (640k/1536k)
- Handles all stereo (2.0) non-Dolby/non-AAC codecs properly
- Complete logic verification for all codec types and channel configurations
- All Dolby codecs (TrueHD/Atmos, AC3, EAC3) properly preserved at all channel counts
- AAC codecs properly preserved at all channel counts (prevents quality degradation)
- Comprehensive testing: DTS, FLAC, Opus, Vorbis, TrueHD, AC3, EAC3, AAC (2.0, 5.1, 7.1)

**<span style="color:#56adda">1.2.0</span>**
- MAJOR UPGRADE: Complete rewrite with AAC stereo support
- Creates AAC Stereo 2.0 from ALL surround audio (Mi Box/mobile optimized)
- Creates AC3 Stereo 2.0 from ALL surround audio (TV fallback)
- Handles DTS/FLAC/Opus 2.0 stereo correctly (converts with stereo bitrates, not surround)
- Separate bitrate controls for stereo (AAC/AC3) and surround (AC3/EAC3)
- Smart codec detection: Dolby (TrueHD/AC3/EAC3) and AAC always preserved
- Only converts non-Dolby/non-AAC codecs to AC3/EAC3 surround
- Prevents quality loss: AAC 5.1 kept (not converted to inferior AC3)
- Processing order prevents infinite loop (stereo first, surround second)
- Configurable bitrates: AAC (96k-320k), AC3 stereo (128k-320k), AC3 surround (384k-640k), EAC3 (768k-1536k)

**<span style="color:#56adda">1.1.0</span>**
- MAJOR FEATURE: Universal stereo downmix from ANY surround audio (> 2.0 channels)
- Now processes ALL audio codecs, not just DTS/FLAC
- Creates AC3 stereo 2.0 downmix from TrueHD, AAC, Opus, etc
- Processing order: stereo downmix first, then AC3/EAC3 (DTS/FLAC only)
- Prevents infinite loop by processing only original streams
- New setting: "Create stereo downmix" with configurable bitrate (128k-256k)
- Keeps non-DTS/FLAC originals (e.g., TrueHD Atmos preserved)
- Only removes DTS/FLAC originals when "remove_original" is enabled

**<span style="color:#56adda">1.0.4</span>**
- Improved audio track titles with proper channel detection
- Mono shows as "AC3 Mono (256k)" instead of "AC3 1.0"
- Stereo shows as "AC3 Stereo (256k)" instead of "AC3 2.0"
- 5.1 shows as "AC3 5.1 (640k)" (6 channels detected)
- 7.1 shows as "AC3 7.1 (640k)" (8 channels detected)
- Preserves original language metadata (Korean, English, etc)

**<span style="color:#56adda">1.0.3</span>**
- Added descriptive titles to audio tracks for easy identification
- AC3 tracks now show: "AC3 5.1 (640k)" instead of copying original title
- EAC3 tracks now show: "EAC3 5.1 (1536k)" instead of copying original title

**<span style="color:#56adda">1.0.2</span>**
- CRITICAL FIX: Added missing lib/ffmpeg helper module
- Plugin will now load correctly and show configuration options
- Fixed import path to use plugin's own ffmpeg module

**<span style="color:#56adda">1.0.1</span>**
- Fixed: Added missing input_type="checkbox" for all boolean settings
- Now checkboxes will display correctly in UI

**<span style="color:#56adda">1.0.0</span>**
- Initial release
- Convert DTS (all variants) to AC3 and/or EAC3
- Convert FLAC (all channel configs) to AC3 and/or EAC3
- Configurable bitrates for both AC3 and EAC3
- Option to create dual tracks (AC3 + EAC3)
- Option to remove original DTS/FLAC after conversion
- Automatic downmix of 7.1+ to 5.1
- Ignores TrueHD, Atmos, and other codecs
